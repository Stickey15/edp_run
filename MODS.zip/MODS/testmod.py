import sys
import os
import pygame
import time
import random
from pathlib import Path

# get working dir
current = os.path.dirname(os.path.realpath(__file__))

# parent dir
parent = os.path.dirname(current)

print("parent: " + parent)

# adding the parent directory to the sys path
sys.path.append(parent)


execurrent = os.path.dirname(sys.executable)


import __main__

__main__.car = pygame.image.load(execurrent + '/MODS/car.png')
__main__.player = pygame.image.load(execurrent + '/MODS/player.png')
__main__.background = pygame.image.load(execurrent + '/MODS/background.png')
__main__.title_surface = pygame.image.load(execurrent + '/MODS/deathscreen.png')



#OVERWRITE GAME UPDATE FUNCTION
from __main__ import game_update_and_render

#Import variables
from __main__ import screen,title_surface,objects,GameObject,background,background_pos,player,player_pos,speed,dt,font,car,pygame

pygame.display.set_mode((1700, 700))

def replace_game():
    global gamestarted, alive, score, running, text_surface
    print("modded thread")  

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            return

    if not gamestarted:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE]:
            gamestarted = True
        return

    if len(objects) < 5:
        o = GameObject(car, 0, 0)
        objects.append(o)

    screen.fill('purple')
    scaled_bg = pygame.transform.scale(background, (1700, 1400))
    screen.blit(scaled_bg, background_pos)
    screen.blit(text_surface, (0, 0))

    player_rect = player.get_rect(topleft=(player_pos.x, player_pos.y))

    for o in objects[:]:
        o.move()
        obj_rect = o.image.get_rect(topleft=(o.pos.x, o.pos.y))
        screen.blit(o.image, o.pos)

        if player_rect.colliderect(obj_rect) and pygame.time.get_ticks() > 1000:
            alive = False

            screen.fill('black')
            x = (screen.get_width() - title_surface.get_width()) / 2
            y = (screen.get_height() - title_surface.get_height()) / 2 - 10
            screen.blit(title_surface, (x, y))
            screen.blit(text_surface,
                        (screen.get_width() / 2 - text_surface.get_width() / 2,
                        screen.get_height() / 2))

            return

    screen.blit(player, (player_pos.x, player_pos.y))

    keys = pygame.key.get_pressed()

    player_pos.x = pygame.mouse.get_pos()[0] - 25
    pygame.mouse.set_visible(False)

    if keys[pygame.K_a]:
        if player_pos.x < -50:
            player_pos.x = 1700
        else:
            player_pos.x -= speed * dt

    if keys[pygame.K_d]:
        if player_pos.x > 1700:
            player_pos.x = -50
        else:
            player_pos.x += speed * dt

    text_surface = font.render(f'Score: {score}', False, (255, 255, 255))

    mod_text_surface = font.render(f'MOD LOADED', False, (255, 0, 255))
    #mod_text_surface = font.render(f'Background Y: {background_pos.y}', False, (255, 0, 255))
    screen.blit(mod_text_surface, (0, 50))

game_update_and_render = lambda : replace_game()

from __main__ import GameObject

def replace_move(self):
    self.pos = self.pos.move(self.speed, 0)
    while any((self.pos.colliderect(o.pos) for o in objects if self!= o)):
        self.pos.x = random.randrange(50, 1600)
    if self.pos.y > 750:
        if self.pos.y >= 750:
            self.pos.y = 0 - random.randrange(10, 200)
            self.pos.x = random.randrange(50, 1600)
            time.sleep(0.01)
    else:
        if alive == True:
            self.pos.y += score * 20 * dt

GameObject.move = lambda self: replace_move(self)



__main__.score = 20

def patched_roadmove():
    print("patched thread")
    while __main__.alive:
        if __main__.background_pos.y >= 0:
            __main__.background_pos.y = -1400
        else:
            if __main__.score < 10:
                __main__.background_pos.y += __main__.score * 15 * __main__.dt
            else:
                __main__.background_pos.y += __main__.score * 10 * __main__.dt
        
        time.sleep(0.01)

__main__.roadmove = patched_roadmove